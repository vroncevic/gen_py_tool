# -*- coding: UTF-8 -*-

'''
Module
    engine.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Main engine orchestrator class for Task Code Generator CLI.
'''

from typing import override
from os.path import dirname, realpath
from ats_utilities.base.engine import Base
from ats_utilities.base.component_bundle import BaseComponentBundle
from ats_utilities.option.ioption_parser import IOptionManager
from ats_utilities.exceptions.ats_value_error import ATSValueError
from ${project_name}.${project_name}_bundle import ${project_name_camel}Bundle
from ${project_name}.domain.ports.iservice import IService
from ${project_name}.application.service import Service
from ${project_name}.domain.ports.isubprocessor import ISubProcessor
from ${project_name}.infrastructure.subprocessor import SubProcessor
from ${project_name}.infrastructure.icli_command import ICLICommand
from ${project_name}.infrastructure.ping_command import PingCommand
from ${project_name}.infrastructure.cli_bundle import CLIBundle
from ${project_name}.infrastructure.icli import ICLI
from ${project_name}.infrastructure.cli import CLI

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class ${project_name_camel}(Base):
    '''
        Engine orchestrating the initialization and execution of ${project_name_camel}.

        It defines:

            :attributes:
                | _info_file - Path to the info file.
                | _cli - Adapter for command line user interface.
            :methods:
                | __init__ - Initializes the ${project_name_camel} engine with adapters and services.
                | run - Starts the ${project_name}.
    '''

    _info_file: str = 'infrastructure/config/${project_name}.cfg'

    def __init__(self, component_bundle: ${project_name_camel}Bundle | None = None) -> None:
        '''
            Initializes the ${project_name_camel} engine with adapters and services.

            :param component_bundle: ${project_name_camel} bundle containing adapters and services | None.
            :type component_bundle: <${project_name_camel}Bundle | None>
            :exceptions: None.
        '''
        current_dir: str = dirname(realpath(__file__))
        super().__init__(BaseComponentBundle(info_file=f'{current_dir}/{self._info_file}'))

        try:
            if not self._is_initialized:
                raise ATSValueError(f'failed to initialize base engine with info file {current_dir}/{self._info_file}')

            # Mark as not initialized (waiting for other components to be initialized)
            self._is_initialized = False

            # Dependency injection: Dependency Inversion Principle
            # Use provided component bundle or use default adapters
            bundle: ${project_name_camel}Bundle = component_bundle or ${project_name_camel}Bundle()

            # Initialization of option manager adapter (Adapter for options parsing)
            parser: IOptionManager = bundle.parser or self._options_parser

            # Initialization of secondary adapter (Service)
            # Sub processor for execution of other tools/commands
            # Force default implementation of sub processor if not provided by bundle
            subprocessor: ISubProcessor = bundle.subprocessor or SubProcessor()

            # Injecting adapter into the application service (Orchestration)
            # Force default implementation of service if not provided by bundle
            service: IService = bundle.service or Service(subprocessor=subprocessor)

            # Setting up CLI command strategies
            commands: list[ICLICommand] = [PingCommand()]

            # Setting up primary adapter (CLI interface)
            cli_bundle: CLIBundle = CLIBundle(service=service, parser=parser, commands=commands)
            self._cli: ICLI = bundle.cli or CLI(cli_bundle)

            # Mark as initialized (all components initialized)
            self._is_initialized = all([
               component.is_initialized() for component in [parser, subprocessor, service, self._cli] if component
            ])

        except ATSValueError as exc:
            self._reporter.error([f'${project_name}: {exc}'])
        except Exception as exc:
            self._reporter.error([f'${project_name} unexpected exception: {exc}'])

    @override
    def process(self) -> None:
        '''
            Runs the ${project_name}.

            :exceptions: None.
        '''
        if self.is_initialized():
            self._cli.run()

