# -*- coding: UTF-8 -*-

'''
Module
    ping_command.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines PingCommand class implementing ICLICommand strategy.
'''

from typing import Any, override
from ats_utilities.factory_class import format_instance_to_string
from ats_utilities.option.command_option import CommandOption
from ${project_name}.infrastructure.icli_command import ICLICommand
from ${project_name}.domain.ports.iservice import IService

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class PingCommand(ICLICommand):
    '''
        CLI subcommand for pinging destination host.

        It defines:

            :attributes: None.
            :methods:
                | name - Returns the command name key.
                | help_text - Returns the command help text.
                | options - Returns the list of command options.
                | to_tool_args - Converts the subcommand parameters to tool arguments.
                | execute - Executes the subcommand.
                | __str__ - Returns the PingCommand as string representation.
    '''

    @property
    @override
    def name(self) -> str:
        '''
            Returns the command name key.

            :return: The command name key.
            :rtype: <str>
            :exceptions: None.
        '''
        return "ping"

    @property
    @override
    def help_text(self) -> str:
        '''
            Returns the command help text.

            :return: The command help text.
            :rtype: <str>
            :exceptions: None.
        '''
        return "Ping destination host"

    @property
    @override
    def options(self) -> list[CommandOption]:
        '''
            Returns the command options.

            :return: List of command options.
            :rtype: <list[CommandOption]>
            :exceptions: None.
        '''
        return [
            CommandOption(
                name="--hostname",
                help_text="Destination host address",
                default="localhost"
            ),
            CommandOption(
                name="--count",
                help_text="Number of pings",
                default=1
            )
        ]

    def to_tool_args(self, params: dict[str, Any]) -> list[str]:
        '''
            Converts subcommand parameters to the list of tool arguments.

            :param params: Subcommand parameters from CLI parser.
            :type params: <dict[str, Any]>
            :return: The list of tool arguments.
            :rtype: <list[str]>
            :exceptions:
                | ValueError: Params must be provided.
        '''
        if not params:
            raise ValueError("params must be provided.")

        param_mapping: dict[str, str | None] = {
            "hostname": None,
            "count": "-c"
        }

        cli_params: list[str] = [self.name]

        for key, value in params.items():

            if key in param_mapping:
                flag: str | None = param_mapping[key]

                if flag:
                    cli_params.extend([flag, str(value)])
                else:
                    cli_params.append(str(value))

        return cli_params

    @override
    def execute(self, params: dict[str, Any], service: IService) -> None:
        '''
            Executes the subcommand.

            :param params: Subcommand parameters from CLI parser.
            :type params: <dict[str, Any]>
            :param service: Command orchestrator service instance.
            :type service: <IService>
            :exceptions: None.
        '''
        print(f"🔥 Executing {self.name} command...")
        service.execute(params=self.to_tool_args(params))
        print(f"✅ Executed {self.name} command.")

    @override
    def __str__(self) -> str:
        '''
            Returns the PingCommand as string representation.

            :return: The PingCommand as string representation.
            :rtype: <str>
            :exceptions: None.
        '''
        return format_instance_to_string(self)
