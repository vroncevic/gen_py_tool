
python3 main.py ping --hostname localhost --count 3

