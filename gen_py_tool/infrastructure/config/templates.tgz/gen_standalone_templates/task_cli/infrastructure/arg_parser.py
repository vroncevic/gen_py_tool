# -*- coding: UTF-8 -*-

'''
Module
    argparse_parser_adapter.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines ArgParser class implementing IArgParser.
'''

from typing import Any, override
from argparse import ArgumentParser, _SubParsersAction
from ${project_name}.infrastructure.iarg_parser import IArgParser
from ${project_name}.infrastructure.icli_command import ICLICommand

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class ArgParser(IArgParser):
    '''
        Argparse implementation of IArgParser.

        It defines:

            :attributes:
                | _parser - argparse.ArgumentParser instance.
                | _subparsers - Subparsers action for subcommand registration.
            :methods:
                | register_commands - Registers commands using argparse subparsers.
                | parse - Parses arguments from argparse and returns parameters.
    '''

    def __init__(self, parser: ArgumentParser | None = None, description: str | None = None):
        '''
            Initializes the ArgParser with CLI description.

            :param parser: Optional ArgumentParser instance | None.
            :type parser: <ArgumentParser | None>
            :param description: CLI tool description.
            :type description: <str | None>
            :exceptions: None.
        '''
        self._parser: ArgumentParser = parser or ArgumentParser(description=description)
        self._subparsers: _SubParsersAction | None = None

    @override
    def register_commands(self, commands: list[ICLICommand]) -> None:
        '''
            Registers commands using argparse subparsers.

            :param commands: List of commands to register.
            :type commands: <list[ICLICommand]>
            :exceptions: None.
        '''
        self._subparsers = self._parser.add_subparsers(dest="command", required=True, help="Available commands")
        for cmd in commands:
            cmd_parser: _SubParsersAction = self._subparsers.add_parser(cmd.name, help=cmd.help_text)

            for opt in cmd.options:
                kwargs: dict[str, Any] = {}

                if opt.default is not None:
                    kwargs["default"] = opt.default

                if opt.required:
                    kwargs["required"] = opt.required

                if opt.choices is not None:
                    kwargs["choices"] = opt.choices

                kwargs["help"] = opt.help_text
                cmd_parser.add_argument(opt.name, **kwargs)

    @override
    def parse(self) -> tuple[str, dict[str, Any]]:
        '''
            Parses arguments from argparse and returns parameters.

            :return: Tuple containing command name and parsed parameters.
            :rtype: <tuple[str, dict[str, Any]]>
            :exceptions: None.
        '''
        params: dict[str, Any] = vars(self._parser.parse_args())
        command_name: str = params.pop("command")

        return command_name, params
