# -*- coding: UTF-8 -*-

'''
Module
    test_infrastructure.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Unit tests for infrastructure adapters.
'''

import unittest
from unittest.mock import patch, MagicMock, call
from typing import Any
from ${project_name}.infrastructure.ping_command import PingCommand
from ${project_name}.infrastructure.command_option import CommandOption
from ${project_name}.infrastructure.icli_command import ICLICommand
from ${project_name}.infrastructure.iarg_parser import IArgParser
from ${project_name}.infrastructure.arg_parser import ArgParser
from ${project_name}.infrastructure.cli_bundle import CLIBundle
from ${project_name}.infrastructure.icli import ICLI
from ${project_name}.infrastructure.cli import CLI
from ${project_name}.domain.ports.iservice import IService
from subprocess import CompletedProcess
from ${project_name}.domain.ports.isubprocessor import ISubProcessor
from ${project_name}.infrastructure.subprocessor import SubProcessor

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class DummyCommand(ICLICommand):
    '''
        Dummy CLI command for testing ArgParser.

        It defines:

            :attributes: None
            :methods:
                | name - Command name.
                | help_text - Command help text.
                | options - Command options.
                | execute - Simulates command execution.
    '''

    @property
    def name(self) -> str:
        '''
            Returns command name.

            :return: The command name.
            :rtype: <str>
            :exceptions: None.
        '''
        return "dummy"

    @property
    def help_text(self) -> str:
        '''
            Returns command help text.

            :return: The command help.
            :rtype: <str>
            :exceptions: None.
        '''
        return "Dummy command for tests"

    @property
    def options(self) -> list[CommandOption]:
        '''
            Returns command options.

            :return: List of command options.
            :rtype: <List[CommandOption]>
            :exceptions: None.
        '''
        return [
            CommandOption(name="--foo", help_text="foo parameter", default="bar"),
            CommandOption(name="--req", help_text="required parameter", required=True),
            CommandOption(name="--list", help_text="list parameter", required=False, choices=['1', '2', '3'], nargs='+')
        ]

    def execute(self, params: dict[str, Any], service: IService) -> None:
        '''
            Simulates execution.

            :param params: Execution params.
            :type params: <dict[str, Any]>
            :param service: Execution service.
            :type service: <IService>
            :exceptions: None.
        '''
        pass


class TestInfrastructure(unittest.TestCase):
    '''
        Defines infrastructure adapters unit tests.

        It defines:

            :attributes: None
            :methods:
                | test_arg_parser_success - Tests successful CLI argument parsing.
                | test_arg_parser_with_list_choice - Tests successful parsing of list parameter with choices.
                | test_cli_bundle_validation - Tests validation checks of CLIBundle.
                | test_cli_run - Tests CLI main execution flow.
                | test_cli_bundle_helpers - Tests CLIBundle helper methods.
    '''

    def test_arg_parser_success(self) -> None:
        '''
            Tests successful registration and parsing of CLI arguments.

            :exceptions: None.
        '''
        parser: IArgParser = ArgParser(description="Test CLI")
        cmd: ICLICommand = DummyCommand()
        parser.register_commands([cmd])

        test_args: list[str] = ["main.py", "dummy", "--req", "val", "--foo", "baz"]
        with patch("sys.argv", test_args):
            cmd_name, params = parser.parse()

        self.assertEqual(cmd_name, "dummy")
        self.assertEqual(params["req"], "val")
        self.assertEqual(params["foo"], "baz")

    def test_arg_parser_with_list_choice(self) -> None:
        '''
            Tests successful parsing of list parameter with choices.

            :exceptions: None.
        '''
        parser: IArgParser = ArgParser(description="Test CLI")
        cmd: ICLICommand = DummyCommand()
        parser.register_commands([cmd])

        test_args: list[str] = ["main.py", "dummy", "--req", "val", "--list", "1"]
        with patch("sys.argv", test_args):
            cmd_name, params = parser.parse()

        self.assertEqual(cmd_name, "dummy")
        self.assertEqual(params["req"], "val")
        self.assertEqual(params["list"], ["1"])

    def test_cli_bundle_validation(self) -> None:
        '''
            Tests validation checks of CLIBundle.

            :exceptions: None.
        '''
        bundle: CLIBundle = CLIBundle(service=None, parser=None, commands=None)
        with self.assertRaises(ValueError):
            bundle.validate()

        bundle1: CLIBundle = CLIBundle(service=MagicMock(spec=IService), parser=None, commands=None)
        with self.assertRaises(ValueError):
            bundle1.validate()

        bundle2: CLIBundle = CLIBundle(service=MagicMock(spec=IService), parser=MagicMock(spec=IArgParser), commands=None)
        with self.assertRaises(ValueError):
            bundle2.validate()

    def test_cli_bundle_helpers(self) -> None:
        '''
            Tests CLIBundle helper methods (merge, to_dict).

            :exceptions: None.
        '''
        mock_service: MagicMock = MagicMock(spec=IService)
        mock_parser: MagicMock = MagicMock(spec=IArgParser)

        bundle1: CLIBundle = CLIBundle(service=mock_service, parser=None, commands=None)
        bundle2: CLIBundle = CLIBundle(service=None, parser=mock_parser, commands=[])
        bundle1.merge(bundle2)

        self.assertEqual(bundle1.service, mock_service)
        self.assertEqual(bundle1.parser, mock_parser)
        self.assertEqual(bundle1.commands, [])

        d: dict[str, Any] = bundle1.to_dict()
        self.assertEqual(d["service"], mock_service)
        self.assertEqual(d["parser"], mock_parser)
        self.assertEqual(d["commands"], [])

    def test_cli_bundle_instantiation_with_none(self) -> None:
        '''
            Tests CLIBundle instantiation with None values.

            :exceptions: None.
        '''
        with self.assertRaises(ValueError):
            cli: ICLI = CLI(None)
            cli.run()

    def test_cli_run(self) -> None:
        '''
            Tests that CLI.run parses arguments and delegates execution to the matched command.

            :exceptions: None.
        '''
        mock_service: MagicMock = MagicMock(spec=IService)
        mock_parser: MagicMock = MagicMock(spec=IArgParser)
        mock_command: MagicMock = MagicMock(spec=ICLICommand)
        mock_command.name = "dummy"

        mock_parser.parse.return_value = ("dummy", {"foo": "bar"})

        cli_bundle: CLIBundle = CLIBundle(service=mock_service, parser=mock_parser, commands=[mock_command])
        cli: ICLI = CLI(cli_bundle)
        cli.run()

        mock_parser.parse.assert_called_once()
        mock_command.execute.assert_called_once_with({"foo": "bar"}, mock_service)

class TestPingCommand(unittest.TestCase):

    def setUp(self) -> None:
        self.command: ICLICommand = PingCommand()

    def test_to_tool_args_with_none(self) -> None:
        """Cover branch where params is None."""
        with self.assertRaises(ValueError):
            self.command.to_tool_args(None)

    def test_to_tool_args_with_empty_dict(self) -> None:
        """Cover branch where params is an empty dict."""
        with self.assertRaises(ValueError):
            self.command.to_tool_args({})

    def test_to_tool_args_hostname(self) -> None:
        """Cover branch where flag is None."""
        result: list[str] = self.command.to_tool_args({
            "hostname": "google.com"
        })

        self.assertEqual(result, ["ping", "google.com"])

    def test_to_tool_args_count(self) -> None:
        """Cover branch where flag exists."""
        result: list[str] = self.command.to_tool_args({
            "count": 5
        })

        self.assertEqual(
            result,
            ["ping", "-c", "5"]
        )

    def test_to_tool_args_ignores_unknown_param(self) -> None:
        """Cover branch where key not in mapping."""
        result: list[str] = self.command.to_tool_args({
            "unknown": "value"
        })

        self.assertEqual(result, ["ping"])

    def test_to_tool_args_all_params(self) -> None:
        result: list[str] = self.command.to_tool_args({
            "hostname": "google.com",
            "count": 3
        })

        self.assertEqual(
            result,
            ["ping", "google.com", "-c", "3"]
        )

    @patch("builtins.print")
    def test_execute(self, mock_print) -> None:
        service: MagicMock = MagicMock(spec=IService)

        self.command.execute(
            {
                "hostname": "google.com",
                "count": 3
            },
            service
        )

        service.execute.assert_called_once_with(
            params=["ping", "google.com", "-c", "3"]
        )

        mock_print.assert_has_calls([
            call("🔥 Executing ping command..."),
            call("✅ Executed ping command.")
        ])

    @patch.object(PingCommand, "to_tool_args")
    @patch("builtins.print")
    def test_execute_calls_to_tool_args(
        self,
        mock_print,
        mock_to_tool_args
    ) -> None:
        mock_to_tool_args.return_value = [
            "ping",
            "localhost",
            "-c",
            "1"
        ]

        service: MagicMock = MagicMock(spec=IService)

        params: dict[str, Any] = {
            "hostname": "localhost",
            "count": 1
        }

        self.command.execute(params, service)

        mock_to_tool_args.assert_called_once_with(params)

        service.execute.assert_called_once_with(
            params=["ping", "localhost", "-c", "1"]
        )

class TestSubProcessor(unittest.TestCase):
    '''
        Defines unit tests for SubProcessor adapter to achieve 100% coverage.

        It defines:
            :methods:
                | test_run_default_parameters - Tests execution with default parameters.
                | test_run_with_captured_output - Tests execution when capturing output.
                | test_run_with_error_returncode - Tests handling of failing sub-processes.
    '''

    @patch('${project_name}.infrastructure.subprocessor.run')
    def test_run_default_parameters(self, mock_run: MagicMock) -> None:
        '''
            Tests successful sub-process execution with default parameters.
        '''
        mock_completed_process: CompletedProcess = CompletedProcess(
            args=["echo", "hello"],
            returncode=0,
            stdout=None,
            stderr=None
        )
        mock_run.return_value = mock_completed_process

        subprocessor: ISubProcessor = SubProcessor()
        params: list[str] = ["echo", "hello"]
        
        res: dict[str, Any] = subprocessor.run(params)

        mock_run.assert_called_once_with(params, capture_output=False, text=True)
        
        self.assertEqual(res["returncode"], 0)
        self.assertIsNone(res["stdout"])
        self.assertIsNone(res["stderr"])

    @patch('${project_name}.infrastructure.subprocessor.run')
    def test_run_with_captured_output(self, mock_run: MagicMock) -> None:
        '''
            Tests sub-process execution when output capture is requested.
        '''
        mock_completed_process: CompletedProcess = CompletedProcess(
            args=["ls", "-la"],
            returncode=0,
            stdout="total 0\ndrwxr-xr-x",
            stderr=""
        )
        mock_run.return_value = mock_completed_process

        subprocessor: ISubProcessor = SubProcessor()
        params: list[str] = ["ls", "-la"]
        
        res: dict[str, Any] = subprocessor.run(params, capture_output=True, text=True)

        mock_run.assert_called_once_with(params, capture_output=True, text=True)
        self.assertEqual(res["returncode"], 0)
        self.assertEqual(res["stdout"], "total 0\ndrwxr-xr-x")
        self.assertEqual(res["stderr"], "")

    @patch('${project_name}.infrastructure.subprocessor.run')
    def test_run_with_error_returncode(self, mock_run: MagicMock) -> None:
        '''
            Tests sub-process execution that finishes with a non-zero exit code.
        '''
        mock_completed_process: CompletedProcess = CompletedProcess(
            args=["false"],
            returncode=1,
            stdout="",
            stderr="Error: command failed"
        )
        mock_run.return_value = mock_completed_process

        subprocessor: ISubProcessor = SubProcessor()
        params: list[str] = ["false"]
        
        res: dict[str, Any] = subprocessor.run(params, capture_output=True, text=False)

        mock_run.assert_called_once_with(params, capture_output=True, text=False)
        self.assertEqual(res["returncode"], 1)
        self.assertEqual(res["stdout"], "")
        self.assertEqual(res["stderr"], "Error: command failed")
