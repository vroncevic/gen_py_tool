# -*- coding: UTF-8 -*-

'''
Module
    test_engine.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Unit tests for main engine (${project_name_camel}).
'''

import unittest
from unittest.mock import MagicMock, patch
from typing import Any
from ${project_name}.i${project_name} import I${project_name_camel}
from ${project_name}.engine import ${project_name_camel}
from ${project_name}.${project_name}_bundle import ${project_name_camel}Bundle
from ${project_name}.domain.ports.isubprocessor import ISubProcessor
from ${project_name}.domain.ports.iservice import IService
from ${project_name}.infrastructure.iarg_parser import IArgParser
from ${project_name}.infrastructure.icli import ICLI

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class TestEngine(unittest.TestCase):
    '''
        Defines engine unit tests.

        It defines:

            :attributes: None
            :methods:
                | test_default_init - Tests default constructor initialization.
                | test_custom_injection - Tests custom dependency injection in ${project_name_camel}.
                | test_init_failure - Tests engine behavior when dependency initialization fails.
                | test_run_success - Tests that run() executes CLI if initialized.
                | test_run_failure - Tests that run() prints error and does not execute if uninitialized.
                | test_${project_name}_bundle_helpers - Tests ${project_name_camel}Bundle helpers.
    '''

    def test_default_init(self) -> None:
        '''
            Tests default constructor initialization of ${project_name_camel}.

            :exceptions: None.
        '''
        engine: I${project_name_camel} = ${project_name_camel}()
        self.assertIsNotNone(engine)

    def test_custom_injection(self) -> None:
        '''
            Tests custom dependency injection in ${project_name_camel} constructor.

            :exceptions: None.
        '''
        mock_subprocess = MagicMock(spec=ISubProcessor)
        mock_service = MagicMock(spec=IService)
        mock_parser = MagicMock(spec=IArgParser)
        mock_cli = MagicMock(spec=ICLI)

        bundle: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            subprocessor=mock_subprocess,
            service=mock_service,
            parser=mock_parser,
            cli=mock_cli
        )

        engine: I${project_name_camel} = ${project_name_camel}(bundle)
        self.assertTrue(engine._is_initialized)
        self.assertEqual(engine._cli, mock_cli)

    def test_init_failure(self) -> None:
        '''
            Tests engine behavior when dependency initialization fails.

            :exceptions: None.
        '''
        with patch('${project_name}.engine.Service', side_effect=ValueError("Service initialization failed")):
            with patch('builtins.print') as mock_print:
                engine: I${project_name_camel} = ${project_name_camel}()
                self.assertFalse(engine._is_initialized)
                mock_print.assert_called_with("❌ ${project_name}: Service initialization failed")

    def test_run_success(self) -> None:
        '''
            Tests that run() executes CLI if initialized.

            :exceptions: None.
        '''
        mock_cli = MagicMock(spec=ICLI)
        mock_cli.run.return_value = {"returncode": 0, "stdout": "done!"}
        bundle: ${project_name_camel}Bundle = ${project_name_camel}Bundle(cli=mock_cli)

        engine: I${project_name_camel} = ${project_name_camel}(bundle)
        self.assertTrue(engine._is_initialized)

        engine.run()
        mock_cli.run.assert_called_once()

    def test_run_command_error(self) -> None:
        '''
            Tests that run() handles command errors properly when initialized.

            :exceptions: None.
        '''
        mock_cli = MagicMock(spec=ICLI)
        mock_cli.run.return_value = {"returncode": 1, "stderr": "some error"}
        bundle: ${project_name_camel}Bundle = ${project_name_camel}Bundle(cli=mock_cli)

        engine: I${project_name_camel} = ${project_name_camel}(bundle)
        self.assertTrue(engine._is_initialized)

        engine.run()
        mock_cli.run.assert_called_once()

    def test_engine_is_initialized(self) -> None:
        '''
            Tests that engine.is_initialized() returns the correct value.
        '''
        engine: I${project_name_camel} = ${project_name_camel}()
        self.assertTrue(engine.is_initialized())

        bundle: ${project_name_camel}Bundle = ${project_name_camel}Bundle()
        engine: I${project_name_camel} = ${project_name_camel}(bundle)
        self.assertTrue(engine.is_initialized())

    def test_run_failure(self) -> None:
        '''
            Tests that run() prints error and does not execute if uninitialized.

            :exceptions: None.
        '''
        with patch('${project_name}.engine.Service', side_effect=ValueError("service initialization failed.")):
            with patch('builtins.print') as mock_print:
                engine: I${project_name_camel} = ${project_name_camel}()
                engine.run()
                mock_print.assert_any_call("❌ ${project_name}: service initialization failed.")
                mock_print.assert_any_call("❌ ${project_name}: engine not initialized.")

    def test_run_failure_with_unexpected_exception(self) -> None:
        '''
            Tests that run() prints error and does not execute if unexpected exception.

            :exceptions: None.
        '''
        with patch('${project_name}.engine.Service', side_effect=RuntimeError("unexpected error.")):
            with patch('builtins.print') as mock_print:
                engine: I${project_name_camel} = ${project_name_camel}()
                engine.run()
                mock_print.assert_any_call("❌ ${project_name} unexpected exception: unexpected error.")

    def test_${project_name}_bundle_helpers(self) -> None:
        '''
            Tests ${project_name_camel}Bundle merge and to_dict helpers.

            :exceptions: None.
        '''
        subprocess1: MagicMock = MagicMock(spec=ISubProcessor)
        service1: MagicMock = MagicMock(spec=IService)
        parser1: MagicMock = MagicMock(spec=IArgParser)
        cli1: MagicMock = MagicMock(spec=ICLI)

        bundle1: ${project_name_camel}Bundle = ${project_name_camel}Bundle(subprocessor=subprocess1, service=None)
        bundle2: ${project_name_camel}Bundle = ${project_name_camel}Bundle(subprocessor=None, service=service1)
        bundle1.merge(bundle2)

        self.assertEqual(bundle1.subprocessor, subprocess1)
        self.assertEqual(bundle1.service, service1)

        d: dict[str, Any] = bundle1.to_dict()
        self.assertEqual(d["subprocessor"], subprocess1)
        self.assertEqual(d["service"], service1)

        bundle3: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            subprocessor=None, service=service1, parser=parser1, cli=cli1
        )

        with self.assertRaises(ValueError):
            bundle3.validate()


        bundle4: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            subprocessor=subprocess1, service=None, parser=parser1, cli=cli1
        )

        with self.assertRaises(ValueError):
            bundle4.validate()

        bundle5: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            subprocessor=subprocess1, service=service1, parser=None, cli=cli1
        )

        with self.assertRaises(ValueError):
            bundle5.validate()

        bundle6: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            subprocessor=subprocess1, service=service1, parser=parser1, cli=None
        )

        with self.assertRaises(ValueError):
            bundle6.validate()
