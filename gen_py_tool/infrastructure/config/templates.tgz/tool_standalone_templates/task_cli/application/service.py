# -*- coding: UTF-8 -*-

'''
Module
    service.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Service for orchestrating the tool execution process.
'''

from ${project_name}.domain.ports.iservice import IService
from ${project_name}.domain.ports.isubprocessor import ISubProcessor
from ${project_name}.domain.models import Tool

__author__: str = 'Vladimir Roncevic'
__copyright__: str = '(C) 2026, https://vroncevic.github.io/${project_name}'
__credits__: list[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__: str = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__: str = '1.0.0'
__maintainer__: str = 'Vladimir Roncevic'
__email__: str = 'elektron.ronca@gmail.com'
__status__: str = 'Development'


class Service(IService):
    '''
        Service for orchestrating the tool execution process.

        It defines:

            :attributes:
                | _subprocessor - Adapter for executing sub-processes.
            :methods:
                | __init__ - Initializes the Service.
                | execute - Executes a tool using the subprocessor adapter.
    '''

    def __init__(self, subprocessor: ISubProcessor) -> None:
        '''
            Initializes the Service.

            :param subprocessor: Subprocessor adapter.
            :type subprocessor: <ISubProcessor>
            :exceptions:
                | ValueError - Subprocessor must be provided.
        '''
        if subprocessor is None:
            raise ValueError("subprocessor must be provided.")

        self._subprocessor: ISubProcessor = subprocessor

    def execute(self, params: list[str]) -> None:
        '''
            Executes a tool using the subprocessor adapter.

            :param params: Parameters for tool execution.
            :type params: <list[str]>
            :exceptions: None.
        '''
        tool: Tool = Tool.from_params(params=params)

        if tool:
            result = self._subprocessor.run(tool.params, capture_output=True, text=True)

            if result.get("returncode") != 0:
                print(result.get("stderr"))
            else:
                print(result.get("stdout"))
