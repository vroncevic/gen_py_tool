# ${project_name}

<img align="right" src="https://raw.githubusercontent.com/vroncevic/${project_name}/dev/docs/${project_name}_logo.png" width="25%">

**${project_name}** is a Clean Architecture Python CLI tool built on ats-utilities.

Developed in **[python](https://www.python.org/)** code.

The README is used to introduce the modules and provide instructions on
how to install the modules, any machine dependencies it may have and any
other information that should be provided before the modules are installed.

[![${project_name} python checker](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_python_checker.yml/badge.svg)](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_python_checker.yml) [![${project_name} package checker](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_package_checker.yml/badge.svg)](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_package_checker.yml) [![${project_name} interface checker](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_interface_checker.yml/badge.svg)](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_interface_checker.yml) [![${project_name} isp checker](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_isp_checker.yml/badge.svg)](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_isp_checker.yml) [![${project_name} srp checker](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_srp_checker.yml/badge.svg)](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_srp_checker.yml) [![GitHub issues open](https://img.shields.io/github/issues/vroncevic/${project_name}.svg)](https://github.com/vroncevic/${project_name}/issues) [![GitHub contributors](https://img.shields.io/github/contributors/vroncevic/${project_name}.svg)](https://github.com/vroncevic/${project_name}/graphs/contributors)

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
**Table of Contents**

- [🚀 Installation](#-installation)
    - [Install using pip](#install-using-pip)
    - [Install using build](#install-using-build)
    - [Install using py setup](#install-using-py-setup)
    - [Install using docker](#install-using-docker)
- [📦 Dependencies](#-dependencies)
- [📁 Tool structure](#-tool-structure)
  - [✨ Features](#-features)
- [📊 Code coverage](#-code-coverage)
- [🛠 Usage](#-usage)
- [📚 Docs](#-docs)
- [👥 Contributing](#-contributing)
- [📄 Copyright and licence](#-copyright-and-licence)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

### 🚀 Installation

Used next development environment

![debian linux os](https://raw.githubusercontent.com/vroncevic/${project_name}/dev/docs/debtux.png)

[![${project_name} python3 build](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_python3_build.yml/badge.svg)](https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_python3_build.yml)

Currently there are four ways to install package
* Install process based on using pip mechanism
* Install process based on build mechanism
* Install process based on setup.py mechanism
* Install process based on docker mechanism

##### Install using pip

**${project_name}** is located at **[pypi.org](https://pypi.org/project/${project_name}/)**.

You can install by using pip

```bash
# python3
pip3 install ${project_name}
```

##### Install using build

Navigate to release **[page](https://github.com/vroncevic/${project_name}/releases/)** download and extract release archive.

To install **${project_name}** type the following

```bash
tar xvzf ${project_name}-x.y.z.tar.gz
cd ${project_name}-x.y.z/
# python3
wget https://bootstrap.pypa.io/get-pip.py
python3 get-pip.py
python3 -m pip install --upgrade setuptools
python3 -m pip install --upgrade pip
python3 -m pip install --upgrade build
pip3 install -r requirements.txt
python3 -m build --no-isolation --wheel
pip3 install ./dist/${project_name}-*-py3-none-any.whl
rm -f get-pip.py
```

##### Install using py setup

Navigate to **[release page](https://github.com/vroncevic/${project_name}/releases)** download and extract release archive.

To install **${project_name}** locate and run setup.py with arguments

```bash
tar xvzf ${project_name}-x.y.z.tar.gz
cd ${project_name}-x.y.z
# python3
pip3 install -r requirements.txt
python3 setup.py install_lib
python3 setup.py install_egg_info
```

##### Install using docker

You can use Dockerfile to create image/container.

### 📦 Dependencies

**${project_name}** requires next modules and libraries

* [ats-utilities - Python App/Tool/Script Utilities](https://pypi.org/project/ats-utilities/)

### 📁 Tool structure

**${project_name}** is based on OOP and Clean Architecture.

Tool structure

<details>
<summary><b>Click to expand framework structure</b></summary>

```bash
    ${project_name}/
         ├── core/
         │   ├── __init__.py
         │   ├── model/
         │   │   ├── __init__.py
         │   │   └── tool_setup.py
         │   └── service/
         │       ├── engine.py
         │       ├── __init__.py
         │       ├── iservice.py
         │       └── isubprocessor.py
         ├── engine.py
         ├── infrastructure/
         │   ├── cli/
         │   │   ├── engine.py
         │   │   ├── icli.py
         │   │   ├── __init__.py
         │   │   └── setup/
         │   │       ├── bundle.py
         │   │       ├── dep_validator.py
         │   │       ├── dependencies.py
         │   │       ├── factory.py
         │   │       ├── __init__.py
         │   │       ├── keys.py
         │   │       ├── opt_validator.py
         │   │       ├── options.py
         │   │       ├── registry.py
         │   │       └── validator.py
         │   ├── command/
         │   │   ├── bundle.py
         │   │   ├── definition.py
         │   │   ├── executor.py
         │   │   ├── idefinition.py
         │   │   ├── iexecutor.py
         │   │   └── __init__.py
         │   ├── config/
         │   │   ├── ${project_name}.cfg
         │   │   └── ${project_name}.logo
         │   ├── __init__.py
         │   └── subprocessor.py
         ├── __init__.py
         ├── py.typed
         └── setup/
             ├── bundle.py
             ├── dep_validator.py
             ├── dependencies.py
             ├── factory.py
             ├── __init__.py
             ├── keys.py
             ├── opt_validator.py
             ├── options.py
             ├── registry.py
             └── validator.py

     10 directories, 43 files
```
</details>

#### ✨ Features

* Structured according to SOLID principles and Clean Architecture (`core/model`, `core/service`, `infrastructure`, `setup`).
* Decoupled `CLI` -> `CommandExecutor` -> `Service` -> `SubProcessor` execution pipeline outputting status directly to `stdout`.
* Structural `@runtime_checkable` `Protocol` interfaces and strict inward dependency inversion.
* Validated bundles, dependencies, and options via `ats-utilities`.
* Full static typing and 100% unit test coverage.

### 📊 Code coverage

<details>
<summary><b>Click to expand code coverage</b></summary>

| Name | Stmts | Miss | Cover |
|------|-------|------|-------|
| `${project_name}/__init__.py` | 9 | 0 | 100%|
| `${project_name}/core/__init__.py` | 9 | 0 | 100%|
| `${project_name}/core/model/__init__.py` | 9 | 0 | 100%|
| `${project_name}/core/model/tool_setup.py` | 13 | 0 | 100%|
| `${project_name}/core/service/__init__.py` | 9 | 0 | 100%|
| `${project_name}/core/service/engine.py` | 34 | 0 | 100%|
| `${project_name}/core/service/iservice.py` | 14 | 0 | 100%|
| `${project_name}/core/service/isubprocessor.py` | 14 | 0 | 100%|
| `${project_name}/engine.py` | 57 | 0 | 100%|
| `${project_name}/infrastructure/__init__.py` | 9 | 0 | 100%|
| `${project_name}/infrastructure/cli/__init__.py` | 9 | 0 | 100%|
| `${project_name}/infrastructure/cli/engine.py` | 43 | 0 | 100%|
| `${project_name}/infrastructure/cli/icli.py` | 16 | 0 | 100%|
| `${project_name}/infrastructure/cli/setup/__init__.py` | 9 | 0 | 100%|
| `${project_name}/infrastructure/cli/setup/bundle.py` | 23 | 0 | 100%|
| `${project_name}/infrastructure/cli/setup/dep_validator.py` | 33 | 0 | 100%|
| `${project_name}/infrastructure/cli/setup/dependencies.py` | 19 | 0 | 100%|
| `${project_name}/infrastructure/cli/setup/factory.py` | 29 | 0 | 100%|
| `${project_name}/infrastructure/cli/setup/keys.py` | 26 | 0 | 100%|
| `${project_name}/infrastructure/cli/setup/opt_validator.py` | 33 | 0 | 100%|
| `${project_name}/infrastructure/cli/setup/options.py` | 17 | 0 | 100%|
| `${project_name}/infrastructure/cli/setup/registry.py` | 24 | 0 | 100%|
| `${project_name}/infrastructure/cli/setup/validator.py` | 35 | 0 | 100%|
| `${project_name}/infrastructure/command/__init__.py` | 9 | 0 | 100%|
| `${project_name}/infrastructure/command/bundle.py` | 19 | 0 | 100%|
| `${project_name}/infrastructure/command/definition.py` | 28 | 0 | 100%|
| `${project_name}/infrastructure/command/executor.py` | 32 | 0 | 100%|
| `${project_name}/infrastructure/command/idefinition.py` | 21 | 0 | 100%|
| `${project_name}/infrastructure/command/iexecutor.py` | 15 | 0 | 100%|
| `${project_name}/infrastructure/subprocessor.py` | 41 | 0 | 100%|
| `${project_name}/setup/__init__.py` | 9 | 0 | 100%|
| `${project_name}/setup/bundle.py` | 25 | 0 | 100%|
| `${project_name}/setup/dep_validator.py` | 33 | 0 | 100%|
| `${project_name}/setup/dependencies.py` | 21 | 0 | 100%|
| `${project_name}/setup/factory.py` | 45 | 0 | 100%|
| `${project_name}/setup/keys.py` | 27 | 0 | 100%|
| `${project_name}/setup/opt_validator.py` | 33 | 0 | 100%|
| `${project_name}/setup/options.py` | 12 | 0 | 100%|
| `${project_name}/setup/registry.py` | 24 | 0 | 100%|
| `${project_name}/setup/validator.py` | 38 | 0 | 100%|
| **Total** | 925 | 0 | 100% |

</details>

### 🛠 Usage

Install package

```bash
pip3 install ${project_name}
```

Prepare main entry point by downloading [main.py](https://raw.githubusercontent.com/vroncevic/${project_name}/main/main.py) or create your own.

```bash
wget -O main.py https://raw.githubusercontent.com/vroncevic/${project_name}/main/main.py
```

Running tool execution command:

```bash
python3 main.py run --target default
```

### 📚 Docs

[![Documentation Status](https://readthedocs.org/projects/${project_name}/badge/?version=latest)](https://${project_name}.readthedocs.io/en/latest/?badge=latest)

More documentation and info at

* [${project_name}.readthedocs.io](https://${project_name}.readthedocs.io)
* [www.python.org](https://www.python.org/)

### 👥 Contributing

[Contributing to ${project_name}](CONTRIBUTING.md)

### 📄 Copyright and licence

[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0) [![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

Copyright (C) 2026 by [vroncevic.github.io/${project_name}](https://vroncevic.github.io/${project_name})

**${project_name}** is free software; you can redistribute it and/or modify
it under the same terms as Python itself, either Python version 3.x or,
at your option, any later version of Python 3 you may have available.

Lets help and support PSF.

[![Python Software Foundation](https://raw.githubusercontent.com/vroncevic/${project_name}/dev/docs/psf-logo-alpha.png)](https://www.python.org/psf/)

[![Donate](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.python.org/psf/donations/)
