# Contributing to ${project_name}

The following is a set of guidelines for contributing to **${project_name}** and its package, which are hosted in the [${project_name}](https://github.com/vroncevic/${project_name}) on GitHub. These are mostly guidelines, not rules. Use your best judgment, and feel free to propose changes to this document in a pull request.

## Code of Conduct

**${project_name}** project and everyone participating in it is governed by the [${project_name} code of conduct](CODE_OF_CONDUCT.md). By participating, you are expected to uphold this code. Please report unacceptable behavior to [${project_name}](mailto:elektron.ronca@gmail.com).

