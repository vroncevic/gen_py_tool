#!/bin/bash
#
# @brief   ${project_name}
# @version 1.0.0
# @date    Sat Aug 07 07:35:10 2026
# @company None, free software to use 2026
# @author  Vladimir Roncevic <elektron.ronca@gmail.com>
#

python3 coverage/ats_coverage.py ${project_name}
pylint ${project_name} > ${project_name}.report
echo "Done"

