# -*- coding: UTF-8 -*-

'''
Module
    dependencies_test.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines unit tests for ${project_name_camel}BundleDependencies TypedDict.
'''

from __future__ import annotations

from unittest import TestCase, main
from unittest.mock import Mock

from ats_utilities.base.setup.bundle import BaseBundle

from ${project_name}.core.service.iservice import IService
from ${project_name}.core.service.isubprocessor import ISubProcessor
from ${project_name}.infrastructure.cli.icli import ICLI
from ${project_name}.setup.dependencies import ${project_name_camel}BundleDependencies

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class Test${project_name_camel}BundleDependencies(TestCase):
    '''
        Defines unit tests for ${project_name_camel}BundleDependencies TypedDict.

        It defines:

            :methods:
                | test_dependencies_creation - Verifies ${project_name_camel}BundleDependencies entries.
    '''

    def test_dependencies_creation(self) -> None:
        '''
            Verifies ${project_name_camel}BundleDependencies entries.

            :exceptions: None.
        '''
        mock_base: Mock = Mock(spec=BaseBundle)
        mock_service: Mock = Mock(spec=IService)
        mock_subprocessor: Mock = Mock(spec=ISubProcessor)
        mock_cli: Mock = Mock(spec=ICLI)

        dependencies: ${project_name_camel}BundleDependencies = ${project_name_camel}BundleDependencies(
            base=mock_base,
            service=mock_service,
            subprocessor=mock_subprocessor,
            cli=mock_cli
        )

        self.assertIs(dependencies['base'], mock_base)
        self.assertIs(dependencies['service'], mock_service)
        self.assertIs(dependencies['subprocessor'], mock_subprocessor)
        self.assertIs(dependencies['cli'], mock_cli)


if __name__ == '__main__':
    main()

