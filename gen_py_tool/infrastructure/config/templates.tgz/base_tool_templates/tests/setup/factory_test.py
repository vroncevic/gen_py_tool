# -*- coding: UTF-8 -*-

'''
Module
    factory_test.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines unit tests for ${project_name_camel}BundleFactory class.
'''

from __future__ import annotations

from unittest import TestCase, main

from ${project_name}.setup.bundle import ${project_name_camel}Bundle
from ${project_name}.setup.factory import ${project_name_camel}BundleFactory
from ${project_name}.setup.options import ${project_name_camel}BundleOptions

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class Test${project_name_camel}BundleFactory(TestCase):
    '''
        Defines unit tests for ${project_name_camel}BundleFactory class.

        It defines:

            :methods:
                | test_create_bundle_default - Verifies default ${project_name_camel}Bundle creation.
                | test_create_bundle_with_options - Verifies ${project_name_camel}Bundle creation with explicit options.
                | test_get_version - Verifies factory version string.
    '''

    def test_create_bundle_default(self) -> None:
        '''
            Verifies default ${project_name_camel}Bundle creation.

            :exceptions: None.
        '''
        bundle: ${project_name_camel}Bundle = ${project_name_camel}BundleFactory.create_bundle()
        self.assertIsInstance(bundle, ${project_name_camel}Bundle)

    def test_create_bundle_with_options(self) -> None:
        '''
            Verifies ${project_name_camel}Bundle creation with explicit options.

            :exceptions: None.
        '''
        bundle: ${project_name_camel}Bundle = ${project_name_camel}BundleFactory.create_bundle(
            options=${project_name_camel}BundleOptions(info_file=${project_name_camel}BundleFactory.DEFAULT_INFO_FILE)
        )
        self.assertIsInstance(bundle, ${project_name_camel}Bundle)

    def test_get_version(self) -> None:
        '''
            Verifies factory version string.

            :exceptions: None.
        '''
        self.assertEqual(${project_name_camel}BundleFactory.get_version(), '1.0.0')


if __name__ == '__main__':
    main()

