# -*- coding: UTF-8 -*-

'''
Module
    registry_test.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines unit tests for ${project_name_camel}BundleRegistry class.
'''

from __future__ import annotations

from unittest import TestCase, main
from unittest.mock import Mock

from ats_utilities.base.setup.bundle import BaseBundle

from ${project_name}.core.service.iservice import IService
from ${project_name}.core.service.isubprocessor import ISubProcessor
from ${project_name}.infrastructure.cli.icli import ICLI
from ${project_name}.setup.bundle import ${project_name_camel}Bundle
from ${project_name}.setup.dependencies import ${project_name_camel}BundleDependencies
from ${project_name}.setup.registry import ${project_name_camel}BundleRegistry

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class Test${project_name_camel}BundleRegistry(TestCase):
    '''
        Defines unit tests for ${project_name_camel}BundleRegistry class.

        It defines:

            :methods:
                | test_create_bundle - Verifies registry creates validated ${project_name_camel}Bundle.
                | test_get_version - Verifies registry version string.
    '''

    def test_create_bundle(self) -> None:
        '''
            Verifies registry creates validated ${project_name_camel}Bundle.

            :exceptions: None.
        '''
        bundle: ${project_name_camel}Bundle = ${project_name_camel}BundleRegistry.create_bundle(
            dependencies=${project_name_camel}BundleDependencies(
                base=Mock(spec=BaseBundle),
                service=Mock(spec=IService),
                subprocessor=Mock(spec=ISubProcessor),
                cli=Mock(spec=ICLI)
            )
        )
        self.assertIsInstance(bundle, ${project_name_camel}Bundle)

    def test_get_version(self) -> None:
        '''
            Verifies registry version string.

            :exceptions: None.
        '''
        self.assertEqual(${project_name_camel}BundleRegistry.get_version(), '1.0.0')


if __name__ == '__main__':
    main()

