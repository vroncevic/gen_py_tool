# -*- coding: UTF-8 -*-

'''
Module
    subprocessor_test.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines unit tests for SubProcessor adapter.
'''

from __future__ import annotations

from collections.abc import Mapping
from io import StringIO
from unittest import TestCase, main
from unittest.mock import Mock, patch

from ats_utilities.exceptions import ATSTypeError, ATSValueError
from ats_utilities.logger.ilogger import ILogger

from ${project_name}.core.model.tool_setup import ToolSetup
from ${project_name}.infrastructure.subprocessor import SubProcessor

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class TestSubProcessor(TestCase):
    '''
        Defines unit tests for SubProcessor adapter.

        It defines:

            :methods:
                | test_init_validation - Verifies constructor validation for logger.
                | test_run_success - Verifies run writes target output to stdout and logs.
                | test_run_failure - Verifies run handles invalid params gracefully.
                | test_state_and_str - Verifies is_initialized and string representation.
    '''

    def test_init_validation(self) -> None:
        '''
            Verifies constructor validation for logger.

            :exceptions: None.
        '''
        invalid_none: object = None
        invalid_type: object = 'invalid'

        with self.assertRaises(ATSValueError):
            SubProcessor(logger=invalid_none)  # type: ignore[arg-type]

        with self.assertRaises(ATSTypeError):
            SubProcessor(logger=invalid_type)  # type: ignore[arg-type]

    def test_run_success(self) -> None:
        '''
            Verifies run writes target output to stdout and logs.

            :exceptions: None.
        '''
        mock_logger: Mock = Mock(spec=ILogger)
        subprocessor: SubProcessor = SubProcessor(logger=mock_logger)
        buffer: StringIO = StringIO()

        with patch('${project_name}.infrastructure.subprocessor.stdout', buffer):
            result: Mapping[str, object] = subprocessor.run(params=ToolSetup(target='unit'))

        self.assertEqual(result['returncode'], 0)
        self.assertIn('[unit]', str(result['stdout']))
        self.assertIn('[unit]', buffer.getvalue())
        mock_logger.write_log.assert_called_once()

    def test_run_failure(self) -> None:
        '''
            Verifies run handles invalid params gracefully.

            :exceptions: None.
        '''
        subprocessor: SubProcessor = SubProcessor(logger=Mock(spec=ILogger))
        invalid_none: object = None

        result: Mapping[str, object] = subprocessor.run(params=invalid_none)  # type: ignore[arg-type]
        self.assertEqual(result['returncode'], 1)
        self.assertNotEqual(result['stderr'], '')

    def test_state_and_str(self) -> None:
        '''
            Verifies is_initialized and string representation.

            :exceptions: None.
        '''
        subprocessor: SubProcessor = SubProcessor(logger=Mock(spec=ILogger))
        self.assertTrue(subprocessor.is_initialized())
        self.assertIsInstance(str(subprocessor), str)


if __name__ == '__main__':
    main()

