# -*- coding: UTF-8 -*-

'''
Module
    tool_setup_test.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines unit tests for ToolSetup domain model.
'''

from __future__ import annotations

from dataclasses import FrozenInstanceError
from unittest import TestCase, main

from ${project_name}.core.model.tool_setup import ToolSetup

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class TestToolSetup(TestCase):
    '''
        Defines unit tests for ToolSetup domain model.

        It defines:

            :methods:
                | test_create_tool_setup - Verifies ToolSetup creation and target value.
                | test_immutability - Verifies ToolSetup is frozen and immutable.
    '''

    def test_create_tool_setup(self) -> None:
        '''
            Verifies ToolSetup creation and target value.

            :exceptions: None.
        '''
        setup: ToolSetup = ToolSetup(target='alpha')
        self.assertEqual(setup.target, 'alpha')

    def test_immutability(self) -> None:
        '''
            Verifies ToolSetup is frozen and immutable.

            :exceptions: None.
        '''
        setup: ToolSetup = ToolSetup(target='alpha')
        with self.assertRaises(FrozenInstanceError):
            setattr(setup, 'target', 'beta')


if __name__ == '__main__':
    main()

