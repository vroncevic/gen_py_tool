# -*- coding: UTF-8 -*-

'''
Module
    iservice_test.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines unit tests for IService structural protocol.
'''

from __future__ import annotations

from unittest import TestCase, main
from unittest.mock import Mock

from ${project_name}.core.service.engine import Service
from ${project_name}.core.service.iservice import IService
from ${project_name}.core.service.isubprocessor import ISubProcessor

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class TestIService(TestCase):
    '''
        Defines unit tests for IService structural protocol.

        It defines:

            :methods:
                | test_structural_conformance - Verifies Service satisfies IService.
                | test_non_conformance - Verifies plain object does not satisfy IService.
    '''

    def test_structural_conformance(self) -> None:
        '''
            Verifies Service satisfies IService.

            :exceptions: None.
        '''
        service: Service = Service(subprocessor=Mock(spec=ISubProcessor))
        self.assertIsInstance(service, IService)

    def test_non_conformance(self) -> None:
        '''
            Verifies plain object does not satisfy IService.

            :exceptions: None.
        '''
        self.assertNotIsInstance(object(), IService)


if __name__ == '__main__':
    main()

