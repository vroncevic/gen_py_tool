# -*- coding: UTF-8 -*-

'''
Module
    engine.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Engine orchestrating the initialization and execution of ${project_name}.
'''

from __future__ import annotations

from collections.abc import Mapping
from logging import ERROR, INFO
from sys import stdout

from ats_utilities.base.engine import Base
from ats_utilities.exceptions import ATSTypeError, ATSValueError
from ats_utilities.logger.ilogger import ILogger

from ${project_name}.infrastructure.cli.icli import ICLI
from ${project_name}.setup.bundle import ${project_name_camel}Bundle
from ${project_name}.setup.validator import ${project_name_camel}BundleValidator

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ${project_name_camel}(Base):
    '''
        Engine orchestrating the initialization and execution of ${project_name}.

        It defines:

            :attributes:
                | _is_initialized - Flag indicating whether the engine is initialized.
                | _logger - Logger for operational messages during initialization and execution.
                | _cli - Inbound adapter for the command line interface.
            :methods:
                | __init__ - Initializes the ${project_name_camel} engine with validated bundle.
                | process - Processes the ${project_name} commands.
    '''

    _is_initialized: bool
    _logger: ILogger
    _cli: ICLI

    def __init__(self, bundle: ${project_name_camel}Bundle) -> None:
        '''
            Initializes the ${project_name_camel} engine with validated bundle.

            :param bundle: ${project_name_camel} bundle containing adapters and services.
            :exceptions: None.
        '''
        self._is_initialized = False

        try:
            ${project_name_camel}BundleValidator.validate(bundle)
            super().__init__(bundle.base)

            self._is_initialized = False
            self._cli = bundle.cli
            self._is_initialized = all(
                component.is_initialized() for component in (
                    bundle.base.option_manager,
                    bundle.service,
                    bundle.subprocessor,
                    self._cli
                ) if component
            )

            self._logger = self.get_context().logger
            self._logger.write_log(INFO, '✅ ${project_name}: engine initialized successfully!')

        except (ATSValueError, ATSTypeError) as exc:
            stdout.write(f'❌ ${project_name}: {exc}!\n')

        except Exception as exc:
            stdout.write(f'❌ ${project_name} unexpected exception: {exc}!\n')

    def process(self, verbose: bool = False) -> bool:
        '''
            Processes the ${project_name} commands.

            :param verbose: Enable verbose output.
            :return: True if successful, False otherwise.
            :exceptions: None.
        '''
        _ = verbose

        try:
            if self.is_initialized():
                self._logger.write_log(INFO, '🔥 Starting execution command...')
                result: Mapping[str, object] = self._cli.run()
                self._logger.write_log(INFO, '✅ Execution finished!')

                if result.get('returncode') != 0:
                    self._logger.write_log(ERROR, f'❌ ${project_name}: {result.get("stderr") or "failed!"}')
                    return False

                self._logger.write_log(INFO, '✅ ${project_name}: done!')
                self._logger.write_log(INFO, '✅ ${project_name}: exiting successfully!')
                return True

            stdout.write('❌ ${project_name}: engine not initialized!\n')
            return False

        except (ATSValueError, ATSTypeError) as exc:
            stdout.write(f'❌ ${project_name}: {exc}!\n')
            return False

        except Exception as exc:
            stdout.write(f'❌ ${project_name} unexpected exception: {exc}!\n')
            return False

