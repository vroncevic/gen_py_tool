# -*- coding: UTF-8 -*-

'''
Module
    engine.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines application service orchestrating ${project_name} execution.
'''

from __future__ import annotations

from collections.abc import Mapping

from ${project_name}.core.model.tool_setup import ToolSetup
from ${project_name}.core.service.isubprocessor import ISubProcessor

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class Service:
    '''
        Defines class Service implementing IService contract structurally.
        Orchestrates ${project_name} use case execution.

        It defines:

            :attributes:
                | _subprocessor - Driven port adapter for subprocessing.
            :methods:
                | __init__ - Initializes Service constructor.
                | execute - Executes ${project_name} use case.
                | is_initialized - Checks if the service is initialized.
    '''

    _subprocessor: ISubProcessor[ToolSetup, Mapping[str, object]]

    def __init__(self, subprocessor: ISubProcessor[ToolSetup, Mapping[str, object]]) -> None:
        '''
            Initializes Service constructor.

            :param subprocessor: Driven port adapter for subprocessing.
            :exceptions:
                | ValueError: If subprocessor is not provided.
                | TypeError: If subprocessor does not satisfy ISubProcessor.
        '''
        ctx: str = 'service::init(...)'
        msg_subprocessor_none: str = 'the subprocessor must be provided'
        msg_subprocessor_istype: str = f'the subprocessor must be of type {ISubProcessor.__name__}'

        if subprocessor is None:
            raise ValueError(f'{ctx} - {msg_subprocessor_none}')

        if not isinstance(subprocessor, ISubProcessor):
            raise TypeError(f'{ctx} - {msg_subprocessor_istype}')

        self._subprocessor = subprocessor

    def execute(self, *, params: ToolSetup) -> Mapping[str, object]:
        '''
            Executes ${project_name} use case.

            :param params: ToolSetup domain configuration object.
            :return: Mapping containing returncode, stdout, and stderr.
            :exceptions:
                | ValueError: If params is not provided.
                | TypeError: If params is not an instance of ToolSetup.
        '''
        ctx: str = 'service::execute(...)'
        msg_params_none: str = 'the params must be provided'
        msg_params_istype: str = f'the params must be of type {ToolSetup.__name__}'

        if params is None:
            raise ValueError(f'{ctx} - {msg_params_none}')

        if not isinstance(params, ToolSetup):
            raise TypeError(f'{ctx} - {msg_params_istype}')

        return self._subprocessor.run(params=params)

    def is_initialized(self) -> bool:
        '''
            Checks if the service is initialized.

            :return: True if the service is initialized, False otherwise.
            :exceptions: None.
        '''
        return self._subprocessor.is_initialized()

