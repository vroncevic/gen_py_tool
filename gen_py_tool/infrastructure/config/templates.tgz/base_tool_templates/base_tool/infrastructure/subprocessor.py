# -*- coding: UTF-8 -*-

'''
Module
    subprocessor.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines SubProcessor adapter implementing ISubProcessor structurally.
'''

from __future__ import annotations

from collections.abc import Mapping
from logging import INFO
from sys import stdout

from ats_utilities.logger.ilogger import ILogger
from ats_utilities.utils.reflection import to_str
from ats_utilities.validation.check_type import istype
from ats_utilities.validation.check_value import not_none

from ${project_name}.core.model.tool_setup import ToolSetup

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class SubProcessor:
    '''
        Defines class SubProcessor implementing ISubProcessor contract structurally.
        Starter adapter writing execution output to standard output stream.

        It defines:

            :attributes:
                | _logger - Logger used to log operational messages.
                | _is_initialized - Flag indicating initialization state.
            :methods:
                | __init__ - Initializes SubProcessor adapter.
                | run - Outputs target execution status to stdout.
                | is_initialized - Checks if the subprocessor is initialized.
                | __str__ - Returns SubProcessor string representation.
    '''

    _logger: ILogger
    _is_initialized: bool

    def __init__(self, logger: ILogger) -> None:
        '''
            Initializes SubProcessor adapter.

            :param logger: Operational logger instance.
            :exceptions:
                | ATSValueError: If logger is None.
                | ATSTypeError: If logger does not satisfy ILogger.
        '''
        ctx: str = 'subprocessor::init(...)'
        not_none(logger, ctx, 'the logger must be provided')
        istype(logger, ILogger, ctx, f'the logger must be an instance of {ILogger.__name__}')

        self._logger = logger
        self._is_initialized = True

    def run(self, *, params: ToolSetup) -> Mapping[str, object]:
        '''
            Outputs target execution status to stdout.

            :param params: ToolSetup containing target parameter.
            :return: Mapping with returncode, stdout, and stderr messages.
            :exceptions: None.
        '''
        try:
            ctx: str = 'subprocessor::run(...)'
            not_none(params, ctx, 'the params must be provided')
            istype(params, ToolSetup, ctx, f'the params must be an instance of {ToolSetup.__name__}')

            message: str = f'${project_name}: executing setup for target [{params.target}]'
            stdout.write(f'{message}\n')
            self._logger.write_log(INFO, f'    {message}')

            return {
                'returncode': 0,
                'stdout': message,
                'stderr': ''
            }

        except Exception as exc:
            return {
                'returncode': 1,
                'stdout': '',
                'stderr': f'failed to execute ${project_name}: {exc}'
            }

    def is_initialized(self) -> bool:
        '''
            Checks if the subprocessor is initialized.

            :return: True if the subprocessor is initialized, False otherwise.
            :exceptions: None.
        '''
        return self._is_initialized

    def __str__(self) -> str:
        '''
            Returns SubProcessor string representation.

            :return: String representation of SubProcessor.
            :exceptions: None.
        '''
        return to_str(self)

