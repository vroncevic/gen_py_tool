# -*- coding: UTF-8 -*-

'''
Module
    options.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines CLIBundleOptions TypedDict for CLI bundle factory.
'''

from __future__ import annotations

from collections.abc import Mapping
from typing import TypedDict

from ats_utilities.option.imanager import IOptionManager

from ${project_name}.core.model.tool_setup import ToolSetup
from ${project_name}.core.service.iservice import IService

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class CLIBundleOptions(TypedDict):
    '''
        Encapsulates options for CLIBundleFactory.

        It defines:

            :attributes:
                | service - Service for ${project_name} execution.
                | parser - Option manager for command line arguments.
    '''

    service: IService[ToolSetup, Mapping[str, object]]
    parser: IOptionManager

