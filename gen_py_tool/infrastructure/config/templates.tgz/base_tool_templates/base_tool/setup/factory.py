# -*- coding: UTF-8 -*-

'''
Module
    factory.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Factory for creating the ${project_name_camel}Bundle.
'''

from __future__ import annotations

from os.path import abspath, dirname, join
from typing import ClassVar

from ats_utilities.base.setup.bundle import BaseBundle
from ats_utilities.base.setup.factory import BaseBundleFactory
from ats_utilities.base.setup.options import BaseBundleOptions
from ats_utilities.context.bundle import ContextBundle
from ats_utilities.context.factory import ContextBundleFactory

from ${project_name}.core.service.engine import Service
from ${project_name}.infrastructure.cli.engine import CLI
from ${project_name}.infrastructure.cli.setup.bundle import CLIBundle
from ${project_name}.infrastructure.cli.setup.factory import CLIBundleFactory
from ${project_name}.infrastructure.cli.setup.options import CLIBundleOptions
from ${project_name}.infrastructure.subprocessor import SubProcessor
from ${project_name}.setup.bundle import ${project_name_camel}Bundle
from ${project_name}.setup.dependencies import ${project_name_camel}BundleDependencies
from ${project_name}.setup.keys import ${project_name_camel}BundleKeys
from ${project_name}.setup.opt_validator import ${project_name_camel}BundleOptionsValidator
from ${project_name}.setup.options import ${project_name_camel}BundleOptions
from ${project_name}.setup.registry import ${project_name_camel}BundleRegistry

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ${project_name_camel}BundleFactory:
    '''
        Factory for creating the ${project_name_camel}Bundle.

        It defines:

            :attributes:
                | DEFAULT_INFO_FILE - Default path to the ${project_name} info file.
            :methods:
                | create_bundle - Creates ${project_name_camel}Bundle with optional pre-configured options.
                | get_version - Returns the factory version.
    '''

    DEFAULT_INFO_FILE: ClassVar[str] = join(
        dirname(dirname(abspath(__file__))), 'infrastructure', 'config', '${project_name}.cfg'
    )

    @classmethod
    def create_bundle(cls, options: ${project_name_camel}BundleOptions | None = None) -> ${project_name_camel}Bundle:
        '''
            Creates ${project_name_camel}Bundle with optional pre-configured options.

            :param options: Pre-configured options for the ${project_name_camel} bundle.
            :return: Validated ${project_name_camel}Bundle instance.
            :exceptions:
                | ATSValueError: If options, dependencies, or bundle values are invalid.
                | ATSTypeError: If options, dependencies, or bundle types are invalid.
        '''
        if options is not None:
            ${project_name_camel}BundleOptionsValidator.validate(options)

        info_file: str = options[${project_name_camel}BundleKeys.OPTION_INFO_FILE] if options else cls.DEFAULT_INFO_FILE

        context_bundle: ContextBundle = ContextBundleFactory.create_bundle()
        base_bundle: BaseBundle = BaseBundleFactory.create_bundle(
            options=BaseBundleOptions(
                info_file=info_file,
                use_generator=False,
                context_bundle=context_bundle
            )
        )

        subprocessor: SubProcessor = SubProcessor(logger=context_bundle.logger)
        service: Service = Service(subprocessor=subprocessor)

        cli_bundle: CLIBundle = CLIBundleFactory.create_bundle(
            options=CLIBundleOptions(
                service=service,
                parser=base_bundle.option_manager
            )
        )
        cli: CLI = CLI(cli_bundle)

        return ${project_name_camel}BundleRegistry.create_bundle(
            dependencies=${project_name_camel}BundleDependencies(
                base=base_bundle,
                service=service,
                subprocessor=subprocessor,
                cli=cli
            )
        )

    @classmethod
    def get_version(cls) -> str:
        '''
            Returns the factory version.

            :return: Factory version string.
            :exceptions: None.
        '''
        return __version__

