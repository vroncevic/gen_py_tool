# -*- coding: UTF-8 -*-

'''
Module
    bundle.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines the ${project_name_camel}Bundle dataclass.
'''

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from ats_utilities.base.setup.bundle import BaseBundle
from ats_utilities.utils.reflection import instance_to_dict

from ${project_name}.core.model.tool_setup import ToolSetup
from ${project_name}.core.service.iservice import IService
from ${project_name}.core.service.isubprocessor import ISubProcessor
from ${project_name}.infrastructure.cli.icli import ICLI

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


@dataclass(slots=True, frozen=True, kw_only=True)
class ${project_name_camel}Bundle:
    '''
        ${project_name_camel} bundle holding core components and adapters of ${project_name}.

        It defines:

            :attributes:
                | base - Base bundle with framework components.
                | service - Service orchestrating ${project_name} execution.
                | subprocessor - Adapter executing target processing.
                | cli - Command-line interface adapter.
            :methods:
                | to_dict - Converts the ${project_name_camel} bundle to a dictionary.
    '''

    base: BaseBundle
    service: IService[ToolSetup, Mapping[str, object]]
    subprocessor: ISubProcessor[ToolSetup, Mapping[str, object]]
    cli: ICLI

    def to_dict(self) -> dict[str, object]:
        '''
            Converts the ${project_name_camel} bundle to a dictionary.

            :return: Dictionary representation of ${project_name_camel}Bundle.
            :exceptions: None.
        '''
        return instance_to_dict(self)

