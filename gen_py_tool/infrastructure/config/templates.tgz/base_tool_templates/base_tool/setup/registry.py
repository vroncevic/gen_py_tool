# -*- coding: UTF-8 -*-

'''
Module
    registry.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Registry assembling and validating ${project_name_camel}Bundle instances.
'''

from __future__ import annotations

from ${project_name}.setup.bundle import ${project_name_camel}Bundle
from ${project_name}.setup.dep_validator import ${project_name_camel}BundleDependenciesValidator
from ${project_name}.setup.dependencies import ${project_name_camel}BundleDependencies
from ${project_name}.setup.keys import ${project_name_camel}BundleKeys
from ${project_name}.setup.validator import ${project_name_camel}BundleValidator

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ${project_name_camel}BundleRegistry:
    '''
        Registry assembling and validating ${project_name_camel}Bundle instances.

        It defines:

            :methods:
                | create_bundle - Creates a validated ${project_name_camel}Bundle from dependencies.
                | get_version - Returns the registry version.
    '''

    @classmethod
    def create_bundle(cls, dependencies: ${project_name_camel}BundleDependencies) -> ${project_name_camel}Bundle:
        '''
            Creates a validated ${project_name_camel}Bundle from dependencies.

            :param dependencies: ${project_name_camel} bundle dependencies.
            :return: Validated ${project_name_camel}Bundle instance.
            :exceptions:
                | ATSValueError: If dependencies or bundle values are missing.
                | ATSTypeError: If dependencies or bundle types are invalid.
        '''
        ${project_name_camel}BundleDependenciesValidator.validate(dependencies)

        bundle: ${project_name_camel}Bundle = ${project_name_camel}Bundle(
            base=dependencies[${project_name_camel}BundleKeys.DEPENDENCY_BASE],
            service=dependencies[${project_name_camel}BundleKeys.DEPENDENCY_SERVICE],
            subprocessor=dependencies[${project_name_camel}BundleKeys.DEPENDENCY_SUBPROCESSOR],
            cli=dependencies[${project_name_camel}BundleKeys.DEPENDENCY_CLI]
        )

        ${project_name_camel}BundleValidator.validate(bundle)

        return bundle

    @classmethod
    def get_version(cls) -> str:
        '''
            Returns the registry version.

            :return: Registry version string.
            :exceptions: None.
        '''
        return __version__

