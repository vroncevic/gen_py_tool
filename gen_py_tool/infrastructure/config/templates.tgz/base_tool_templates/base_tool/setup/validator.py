# -*- coding: UTF-8 -*-

'''
Module
    validator.py
Copyright
    Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>
    ${project_name} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${project_name} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Validator for ${project_name_camel}Bundle instances.
'''

from __future__ import annotations

from ats_utilities.base.setup.bundle import BaseBundle
from ats_utilities.exceptions import ATSTypeError, ATSValueError
from ats_utilities.validation.check_type import istype
from ats_utilities.validation.check_value import not_none

from ${project_name}.core.service.iservice import IService
from ${project_name}.core.service.isubprocessor import ISubProcessor
from ${project_name}.infrastructure.cli.icli import ICLI
from ${project_name}.setup.bundle import ${project_name_camel}Bundle

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) 2026 Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${project_name}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ${project_name_camel}BundleValidator:
    '''
        Validator for ${project_name_camel}Bundle instances.

        It defines:

            :methods:
                | validate - Validates the ${project_name_camel} bundle.
                | is_valid - Checks if the ${project_name_camel} bundle is valid.
    '''

    @classmethod
    def validate(cls, bundle: ${project_name_camel}Bundle) -> None:
        '''
            Validates the ${project_name_camel} bundle.

            :param bundle: ${project_name_camel} bundle to validate.
            :exceptions:
                | ATSValueError: If bundle or any attribute is None.
                | ATSTypeError: If bundle or any attribute has invalid type.
        '''
        ctx: str = '${project_name}_bundle_validator::validate(...)'
        not_none(bundle, ctx, 'the ${project_name} bundle must be provided')
        istype(bundle, ${project_name_camel}Bundle, ctx, 'the ${project_name} bundle must be an instance of ${project_name_camel}Bundle')

        not_none(bundle.base, ctx, 'the base bundle must be provided')
        not_none(bundle.service, ctx, 'the service must be provided')
        not_none(bundle.subprocessor, ctx, 'the subprocessor must be provided')
        not_none(bundle.cli, ctx, 'the cli must be provided')

        istype(bundle.base, BaseBundle, ctx, 'the base bundle must be an instance of BaseBundle')
        istype(bundle.service, IService, ctx, 'the service must be an instance of IService')
        istype(bundle.subprocessor, ISubProcessor, ctx, 'the subprocessor must be an instance of ISubProcessor')
        istype(bundle.cli, ICLI, ctx, 'the cli must be an instance of ICLI')

    @classmethod
    def is_valid(cls, bundle: ${project_name_camel}Bundle) -> bool:
        '''
            Checks if the ${project_name_camel} bundle is valid.

            :param bundle: ${project_name_camel} bundle to check.
            :return: True if valid, False otherwise.
            :exceptions: None.
        '''
        try:
            cls.validate(bundle)
            return True
        except (ATSValueError, ATSTypeError):
            return False

