${project_name} Python CLI tool
-------------------------

**${project_name}** is a Clean Architecture Python CLI tool built on ats-utilities.

Developed in `python <https://www.python.org/>`_ code.

The README is used to introduce the tool and provide instructions on
how to install the tool, any machine dependencies it may have and any
other information that should be provided before the tool is installed.

|${project_name} python checker| |${project_name} python package| |${project_name} interface checker| |${project_name} isp checker| |${project_name} srp checker| |github issues| |documentation status| |github contributors|

.. |${project_name} python checker| image:: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_python_checker.yml/badge.svg
   :target: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_python_checker.yml

.. |${project_name} python package| image:: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_package_checker.yml/badge.svg
   :target: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_package_checker.yml

.. |${project_name} interface checker| image:: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_interface_checker.yml/badge.svg
   :target: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_interface_checker.yml

.. |${project_name} isp checker| image:: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_isp_checker.yml/badge.svg
   :target: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_isp_checker.yml

.. |${project_name} srp checker| image:: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_srp_checker.yml/badge.svg
   :target: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_srp_checker.yml

.. |github issues| image:: https://img.shields.io/github/issues/vroncevic/${project_name}.svg
   :target: https://github.com/vroncevic/${project_name}/issues

.. |github contributors| image:: https://img.shields.io/github/contributors/vroncevic/${project_name}.svg
   :target: https://github.com/vroncevic/${project_name}/graphs/contributors

.. |documentation status| image:: https://readthedocs.org/projects/${project_name}/badge/?version=latest
   :target: https://${project_name}.readthedocs.io/en/latest/?badge=latest

.. toctree::
   :maxdepth: 4
   :caption: Contents

   self
   modules

🚀 Installation
---------------

|${project_name} python3 build|

.. |${project_name} python3 build| image:: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_python3_build.yml/badge.svg
   :target: https://github.com/vroncevic/${project_name}/actions/workflows/${project_name}_python3_build.yml

Navigate to release `page`_ download and extract release archive.

.. _page: https://github.com/vroncevic/${project_name}/releases

To install **${project_name}** type the following

.. code-block:: bash

    tar xvzf ${project_name}-x.y.z.tar.gz
    cd ${project_name}-x.y.z/
    # python3
    wget https://bootstrap.pypa.io/get-pip.py
    python3 get-pip.py
    python3 -m pip install --upgrade setuptools
    python3 -m pip install --upgrade pip
    python3 -m pip install --upgrade build
    pip3 install -r requirements.txt
    python3 -m build --no-isolation --wheel
    pip3 install ./dist/${project_name}-*-py3-none-any.whl
    rm -f get-pip.py

You can use Docker to create image/container, or You can use pip to install

.. code-block:: bash

    # python3
    pip3 install ${project_name}

📦 Dependencies
---------------

**${project_name}** requires next modules and libraries

* `ats-utilities - Python App/Tool/Script Utilities <https://pypi.org/project/ats-utilities/>`_

📁 Tool structure
-----------------

**${project_name}** is based on OOP and Clean Architecture.

Tool structure

.. code-block:: bash

    ${project_name}/
         ├── core/
         │   ├── __init__.py
         │   ├── model/
         │   │   ├── __init__.py
         │   │   └── tool_setup.py
         │   └── service/
         │       ├── engine.py
         │       ├── __init__.py
         │       ├── iservice.py
         │       └── isubprocessor.py
         ├── engine.py
         ├── infrastructure/
         │   ├── cli/
         │   │   ├── engine.py
         │   │   ├── icli.py
         │   │   ├── __init__.py
         │   │   └── setup/
         │   │       ├── bundle.py
         │   │       ├── dep_validator.py
         │   │       ├── dependencies.py
         │   │       ├── factory.py
         │   │       ├── __init__.py
         │   │       ├── keys.py
         │   │       ├── opt_validator.py
         │   │       ├── options.py
         │   │       ├── registry.py
         │   │       └── validator.py
         │   ├── command/
         │   │   ├── bundle.py
         │   │   ├── definition.py
         │   │   ├── executor.py
         │   │   ├── idefinition.py
         │   │   ├── iexecutor.py
         │   │   └── __init__.py
         │   ├── config/
         │   │   ├── ${project_name}.cfg
         │   │   └── ${project_name}.logo
         │   ├── __init__.py
         │   └── subprocessor.py
         ├── __init__.py
         ├── py.typed
         └── setup/
             ├── bundle.py
             ├── dep_validator.py
             ├── dependencies.py
             ├── factory.py
             ├── __init__.py
             ├── keys.py
             ├── opt_validator.py
             ├── options.py
             ├── registry.py
             └── validator.py

     10 directories, 43 files

✨ Features
-----------

* Structured according to SOLID principles and Clean Architecture.
* Decoupled CLI -> CommandExecutor -> Service -> SubProcessor execution pipeline outputting status directly to stdout.
* Structural runtime-checkable Protocol interfaces and strict inward dependency inversion.
* Validated bundles, dependencies, and options via ats-utilities.
* Full static typing and 100% unit test coverage.

📊 Code coverage
----------------

.. csv-table:: Code coverage
   :file: coverage_table.csv
   :widths: 60, 10, 10, 20
   :header-rows: 1

🛠 Usage
--------

Install package

.. code-block:: bash

    pip3 install ${project_name}

Prepare main entry point by downloading `main.py` or create your own.

.. code-block:: bash

    wget -O main.py https://raw.githubusercontent.com/vroncevic/${project_name}/main/main.py

Running tool execution command

.. code-block:: bash

    python3 main.py run --target default

📚 Docs
-------

More documentation and info at

* `${project_name}.readthedocs.io <https://${project_name}.readthedocs.io>`_
* `www.python.org <https://www.python.org/>`_

👥 Contributing
---------------

`Contributing to ${project_name} <https://github.com/vroncevic/${project_name}/blob/dev/CONTRIBUTING.md>`_

📄 Copyright and licence
-------------------------

Copyright (C) 2026 by `vroncevic.github.io/${project_name} <https://vroncevic.github.io/${project_name}>`_

**${project_name}** is free software; you can redistribute it and/or modify
it under the same terms as Python itself, either Python version 3.x or,
at your option, any later version of Python 3 you may have available.

Lets help and support PSF.
